# F1 Race Result Prediction

Este proyecto utiliza Machine Learning para predecir resultados de carreras de Fórmula 1.